# Private Portfolio Tracker (Streamlit + yfinance)

## Run
pip install -r requirements.txt
# set your passcode:
# create .streamlit/secrets.toml with:  passcode = "change-me"
streamlit run app.py
